package com.pingan.ocft.intelligentcertify;

import android.Manifest;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.ocft.facedetect.library.facedetector.OcftFaceDetectorConfig;
import com.pingan.ocft.intelligentcertify.utils.StatusBarUtil;
import com.pingan.ocft.intelligentcertify.utils.UserConstants;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.PermissionListener;
import com.yanzhenjie.permission.Rationale;
import com.yanzhenjie.permission.RationaleListener;

import java.util.List;

/**
 * Created by luoqianfeng779 on 2017/9/18.
 * */

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

  private ImageView iv_2Ocr;
  private ImageView iv_2Face;
  private ImageView iv_2Face2;
  private Switch switch_location;
  private Switch switch_location2;
  private Spinner spinner_type1;
  private Spinner spinner_type2;
  private TextView tv_latitude;
  private TextView tv_latitude2;
  private TextView tv_longitude;
  private TextView tv_longitude2;
  private TextView tv_name;
  private TextView tv_num;
  private ImageView iv_attention;
  private Button btn_face_c_face;
  private Button btn_face_c_id;

  private boolean isLocation;
  private boolean isLocation2;
  private int faceDetectType1;
  private int faceDetectType2;
  private int isFace1 = 0;
  private int isFace2 = 0;
  private byte[] bytes;
  private byte[] bytes1;
  private byte[] bytes2;
  private String idName;
  private String idNum;
  private TextView tv_clear;

  private static final int REQUEST_CODE_PERMISSION_OTHER = 0;
  private static final int REQUEST_CODE_SETTING = 100;
  private boolean hasPermission = false;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    StatusBarUtil.setStatusBarLightMode(this);
    setContentView(R.layout.activity_main);
    initView();
    initEvent();
  }

  private void initView() {
    tv_name = (TextView) findViewById(R.id.tv_name);
    tv_num = (TextView) findViewById(R.id.tv_num);
    iv_2Ocr = (ImageView) findViewById(R.id.camera);
    iv_2Face = (ImageView) findViewById(R.id.iv_face);
    iv_2Face2 = (ImageView) findViewById(R.id.iv_face2);
    switch_location = (Switch) findViewById(R.id.switch_location);
    switch_location2 = (Switch) findViewById(R.id.switch_location2);
    spinner_type1 = (Spinner) findViewById(R.id.spinnerTypes1);
    spinner_type2 = (Spinner) findViewById(R.id.spinnerTypes2);
    tv_latitude = (TextView) findViewById(R.id.tv_latitude);
    tv_longitude = (TextView) findViewById(R.id.tv_longitude);
    tv_latitude2 = (TextView) findViewById(R.id.tv_latitude2);
    tv_longitude2 = (TextView) findViewById(R.id.tv_longitude2);
    iv_attention = (ImageView) findViewById(R.id.iv_attention);
    btn_face_c_face = (Button) findViewById(R.id.btn_face_c_face);
    btn_face_c_id = (Button) findViewById(R.id.btn_face_c_id);
    tv_clear = (TextView) findViewById(R.id.tv_clear);
  }

  private void initEvent() {
    initPremission();

    iv_2Ocr.setOnClickListener(this);
    iv_2Face.setOnClickListener(this);
    iv_2Face2.setOnClickListener(this);
    iv_attention.setOnClickListener(this);
    btn_face_c_face.setOnClickListener(this);
    btn_face_c_id.setOnClickListener(this);
    tv_clear.setOnClickListener(this);
    switch_location.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
      @Override public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        isLocation = b;
      }
    });
    switch_location2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
      @Override public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        isLocation2 = b;
      }
    });
    spinner_type1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
          Log.i("MainActivity", "spinner_type1 onItemSelected i="+i);
          faceDetectType1 = i;
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {

          Log.i("MainActivity", "spinner_type1 onNothingSelected");
        }
    });
    spinner_type2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
      @Override
      public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        Log.i("MainActivity", "spinner_type2 onItemSelected i="+i);
        faceDetectType2 = i;

      }

      @Override
      public void onNothingSelected(AdapterView<?> adapterView) {

        Log.i("MainActivity", "spinner_type2 onNothingSelected");
      }
    });
  }

  @Override public void onClick(View view) {
    switch (view.getId()) {
      case R.id.iv_attention:
        FaceDemandDialog demandDialog = new FaceDemandDialog();
        demandDialog.show(getFragmentManager(), null);
        break;
      case R.id.camera:
        Toast.makeText(getApplication(),"请将手机摄像头横向对准身份证",Toast.LENGTH_LONG).show();
//        Intent intent1 = new Intent(this, OcrActivity.class);
//        startActivityForResult(intent1, 1);
        break;
      case R.id.iv_face:
        isFace1 = 1;
        tv_latitude.setVisibility(View.GONE);
        tv_longitude.setVisibility(View.GONE);
        startFaceActivity(isLocation, faceDetectType1);
        break;
      case R.id.iv_face2:
        isFace2 = 1;
        tv_latitude2.setVisibility(View.GONE);
        tv_longitude2.setVisibility(View.GONE);
        startFaceActivity(isLocation2, faceDetectType2);
        break;
      case R.id.btn_face_c_face:
        if(hasPermission){
          toResultActivity(1);//人人比对
        }else {
          initPremission();
        }
        break;
      case R.id.btn_face_c_id:
        if(bytes1!=null&&bytes2!=null){
          Toast.makeText(getApplication(),"将选取左图用于人证比对",Toast.LENGTH_LONG).show();
        }
        if(hasPermission){
          toResultActivity(2);//人证比对
        }else {
          initPremission();
        }
        break;
      case R.id.tv_clear:
        clearData();
        break;
    }
  }

  private void toResultActivity(int type) {
//    Intent intent = new Intent(this, ResultActivity.class);
//    intent.putExtra("type", type);
//    if(bytes2!=null&&bytes1!=null){
//      intent.putExtra(UserConstants.BYTES1, bytes1);
//    }else {
//      intent.putExtra(UserConstants.BYTES1, bytes);
//    }
//    if (type == 1) {
//      intent.putExtra(UserConstants.BYTES2, bytes2);
//    } else if (type == 2) {
//      intent.putExtra(UserConstants.IDNAME, idName);
//      intent.putExtra(UserConstants.IDNUM, idNum);
//    }
//    startActivity(intent);
  }

  private void startFaceActivity(boolean isLocation, int type) {
    Intent intent2 = new Intent(this, FaceDetectActivity.class);
    intent2.putExtra("isLocation", isLocation);
    intent2.putExtra("detectType", getDetectType(type));
    startActivityForResult(intent2, 2);
  }
  private int getDetectType(int i){
    int type = i;
    switch(i){
      case 0: type = OcftFaceDetectorConfig.MOTION_RANDOM; break;
      case 1: type = OcftFaceDetectorConfig.MOTION_RANDOM; break;
      case 2: type = OcftFaceDetectorConfig.MOTION_MOUTH; break;
      case 3: type = OcftFaceDetectorConfig.MOTION_HEAD; break;
    }
    return type;
  }
  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (data == null) {
      if(isFace1 == 1){ isFace1 = 0; }
      if(isFace2 == 1){ isFace2 = 0; }
      return;
    }
    switch (requestCode) {
      case 1:
        idName = data.getStringExtra(UserConstants.IDNAME);
        idNum = data.getStringExtra(UserConstants.IDNUM);
        tv_name.setText("姓名：" + idName);
        tv_num.setText("身份证号：" + idNum);
        if (bytes != null) {
          btn_face_c_id.setEnabled(true);
        }
        break;
      case 2:
        if (!TextUtils.isEmpty(idName) && !TextUtils.isEmpty(idNum)) {
          btn_face_c_id.setEnabled(true);
        }
        bytes = data.getByteArrayExtra("bytes");
        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        double latitude = data.getDoubleExtra("latitude", 0);
        double longitude = data.getDoubleExtra("longitude", 0);
        if (isFace1 == 1) {
          isFace1 = 0;
          bytes1 = bytes;
          if (bytes2 != null) {
            btn_face_c_face.setEnabled(true);
          }
          iv_2Face.setImageBitmap(bitmap);
          if (isLocation) {
            tv_latitude.setText("经度：" + String.valueOf(latitude));
            tv_longitude.setText("纬度：" + String.valueOf(longitude));
            tv_latitude.setVisibility(View.VISIBLE);
            tv_longitude.setVisibility(View.VISIBLE);
          }
        } else if (isFace2 == 1) {
          isFace2 = 0;
          bytes2 = bytes;
          if (bytes1 != null) {
            btn_face_c_face.setEnabled(true);
          }
          iv_2Face2.setImageBitmap(bitmap);
          if (isLocation2) {
            tv_latitude2.setText("经度：" + String.valueOf(latitude));
            tv_longitude2.setText("纬度：" + String.valueOf(longitude));
            tv_latitude2.setVisibility(View.VISIBLE);
            tv_longitude2.setVisibility(View.VISIBLE);
          }
        }
        break;
      case REQUEST_CODE_SETTING: {
        initPremission();
        break;
      }
    }
  }

  private void clearData() {
    bytes=null;
    bytes1=null;
    bytes2=null;
    idName = null;
    idNum = null;
    isFace1 = 0;
    isFace2 = 0;
    isLocation = false;
    isLocation2 = false;

    tv_name.setText("姓名：");
    tv_num.setText("身份证号：");
    switch_location.setChecked(false);
    switch_location2.setChecked(false);
    iv_2Face.setImageResource(R.mipmap.bg_header);
    iv_2Face2.setImageResource(R.mipmap.bg_header);
    btn_face_c_face.setEnabled(false);
    btn_face_c_id.setEnabled(false);
    tv_latitude.setVisibility(View.GONE);
    tv_latitude2.setVisibility(View.GONE);
    tv_longitude.setVisibility(View.GONE);
    tv_latitude2.setVisibility(View.GONE);
  }


  private void initPremission() {
    // 申请多个权限。
    AndPermission.with(this)
        .requestCode(REQUEST_CODE_PERMISSION_OTHER)
        .permission(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA,Manifest.permission.ACCESS_COARSE_LOCATION)
        .callback(permissionListener)
        // rationale作用是：用户拒绝一次权限，再次申请时先征求用户同意，再打开授权对话框；
        // 这样避免用户勾选不再提示，导致以后无法申请权限。
        // 你也可以不设置。
        .rationale(
                new RationaleListener()    {

                     @Override
                     public void showRequestPermissionRationale(int requestCode, Rationale rationale) {


                       // 这里的对话框可以自定义，只要调用rationale.resume()就可以继续申请。
                       AndPermission.rationaleDialog(MainActivity.this, rationale).show();
                       rationale.resume();
                     }
                   }
        )

        .start();
  }

  /**
   * 回调监听。
   */
  private PermissionListener permissionListener = new PermissionListener() {
    @Override public void onSucceed(int requestCode, List<String> grantPermissions) {
      switch (requestCode) {
        case REQUEST_CODE_PERMISSION_OTHER: {
          hasPermission = true;
          break;
        }
      }
    }

    @Override public void onFailed(int requestCode, List<String> deniedPermissions) {
      switch (requestCode) {
        case REQUEST_CODE_PERMISSION_OTHER: {
          hasPermission = false;
          break;
        }
      }

      // 用户否勾选了不再提示并且拒绝了权限，那么提示用户到设置中授权。
      if (AndPermission.hasAlwaysDeniedPermission(MainActivity.this, deniedPermissions)) {

        AndPermission.defaultSettingDialog(MainActivity.this, REQUEST_CODE_SETTING)
            .setTitle("权限申请失败")
            .setMessage("我们需要的一些权限被您拒绝或者系统发生错误申请失败，请您到设置页面手动授权，否则功能无法正常使用！")
            .setPositiveButton("好，去设置")
            .show();
      }
    }
  };


}
