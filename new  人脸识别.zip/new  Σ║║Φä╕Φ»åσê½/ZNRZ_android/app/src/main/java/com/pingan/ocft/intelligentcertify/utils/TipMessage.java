package com.pingan.ocft.intelligentcertify.utils;

import android.content.Context;

import com.ocft.facedetect.library.common.OcftTips;
import com.pingan.ocft.intelligentcertify.R;

/**
 * Created by luo on 2017/9/27.
 */

public class TipMessage {
    public static String getDescription(int id, Context context) {
        switch (id) {
            case OcftTips.NormalTips.TOO_DARK:
                return context.getString(R.string.tips_description_dark);
            case OcftTips.NormalTips.TOO_BRIGHT:
                return context.getString(R.string.tips_description_light);
            case OcftTips.NormalTips.TOO_FAR:
                return context.getString(R.string.tips_description_far);
            case OcftTips.NormalTips.TOO_FUZZY:
                return context.getString(R.string.tips_description_blur);
            case OcftTips.NormalTips.MULTI_FACE:
                return context.getString(R.string.tips_description_multi_face);
            case OcftTips.NormalTips.NORMAL:
                return context.getString(R.string.tips_description_normal);
            case OcftTips.NormalTips.TOO_PARTIAL:
                return context.getString(R.string.tips_description_partial);
            case OcftTips.NormalTips.NO_FACE:
                return context.getString(R.string.tips_description_no_face);
            case OcftTips.NormalTips.TOO_RIGHT:
                return context.getString(R.string.tips_description_right);
            case OcftTips.NormalTips.TOO_LEFT:
                return context.getString(R.string.tips_description_left);
            case OcftTips.NormalTips.TOO_UP:
                return context.getString(R.string.tips_description_up);
            case OcftTips.NormalTips.TOO_DOWN:
                return context.getString(R.string.tips_description_down);
            case OcftTips.NormalTips.TOO_CLOSE:
                return context.getString(R.string.tips_description_near);
            case OcftTips.NormalTips.EYES_CLOSED:
                return context.getString(R.string.tips_description_eyesclosed);
            case OcftTips.MotionType.MOUTH:
                return context.getString(R.string.tips_description_detect_mouth);
            case OcftTips.MotionType.HEAD:
                return context.getString(R.string.tips_description_detect_head);
            case OcftTips.FailedType.FAILED:
                return context.getString(R.string.tips_description_detection_failed);
            case OcftTips.PaLocationConstants.LOCATION_SUCCESS:
                return context.getString(R.string.tips_description_location_success);
            case OcftTips.PaLocationConstants.LOCATION_ERROR:
                return context.getString(R.string.tips_description_location_error);
            case OcftTips.PaLocationConstants.LOCATION_NO_PROVIDER:
                return context.getString(R.string.tips_description_location_no_provider);
        }
        return "";
    }
}
