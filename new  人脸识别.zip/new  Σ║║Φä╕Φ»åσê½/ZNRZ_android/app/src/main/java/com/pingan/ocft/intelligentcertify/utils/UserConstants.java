package com.pingan.ocft.intelligentcertify.utils;

/**
 * Created by luoqianfeng779 on 2017/9/18.
 */

public class UserConstants {

  public static final String IDNAME = "IdName";
  public static final String IDNUM = "IdNum";

  public static final String BYTES1 = "bytes1";
  public static final String BYTES2 = "bytes2";

}
