package com.pingan.ocft.intelligentcertify;

import android.content.Intent;
import android.graphics.Bitmap;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.ocft.facedetect.library.common.OcftTips;
import com.ocft.facedetect.library.facedetector.OcftFaceDetector;
import com.ocft.facedetect.library.facedetector.OcftFaceDetectorSurfaceView;
import com.ocft.facedetect.library.facedetector.listener.OcftFaceDetectorResult;
import com.ocft.facedetect.library.facedetector.listener.OnOcftFaceDetectorListener;
import com.pingan.ocft.intelligentcertify.utils.StatusBarUtil;

import java.io.ByteArrayOutputStream;
import java.util.Map;

/**
 * Created by luoqianfeng779 on 2017/9/18.
 */

public class FaceDetectActivity extends AppCompatActivity implements OnOcftFaceDetectorListener {

  private FrameLayout frameView;
  private OcftFaceDetector ocftFaceDetector;
  private Intent intent;
  private boolean isLocation;
  private int faceDetectType;
  private TextView tv_tips;

  private int time = 3;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    StatusBarUtil.setWindowStatusBarColor(this, R.color.colorDark);
    setContentView(R.layout.activity_face_detect);
    initData();
    initView();
    initEvent();
  }

  private void initData() {
    intent = getIntent();
    isLocation = intent.getBooleanExtra("isLocation", false);
    faceDetectType = intent.getIntExtra("detectType", 1);
    Log.i("FaceDetectActivity", "faceDetectType=" + faceDetectType);
  }

  private void initView() {
    frameView = (FrameLayout) findViewById(R.id.frame_view);
    TextView tv_is_location = (TextView) findViewById(R.id.tv_is_location);
    tv_tips = (TextView) findViewById(R.id.tv_tips);
    if(isLocation){
      tv_is_location.setText("已开启定位");
    }else {
      tv_is_location.setText("未开启定位");
    }
    initSurfaceView();
  }

  private void initSurfaceView() {
    DisplayMetrics metric = new DisplayMetrics();
    getWindowManager().getDefaultDisplay().getMetrics(metric);
    int width = metric.widthPixels;     // 屏幕宽度（像素）
    int height = metric.heightPixels;   // 屏幕高度（像素）

    ocftFaceDetector = new OcftFaceDetector(this, true, faceDetectType, this);
    OcftFaceDetectorSurfaceView surfaceView = ocftFaceDetector.getSurfaceView();
    FrameLayout.LayoutParams layoutParams =
            new FrameLayout.LayoutParams(width, width * 4 / 3);//比例为4:3
    surfaceView.setLayoutParams(layoutParams);
    frameView.addView(surfaceView);

    Log.i("detectActivity", "getVersion="+OcftFaceDetector.getSDKInfo().getVersion());
  }

  private void initEvent() {
    //人脸检测设置项
//    ocftFaceDetector.setCameraMode(Camera.CameraInfo.CAMERA_FACING_FRONT);
//    ocftFaceDetector.setDetectModes(OcftFaceDetectorConfig.LDM_RANDOM_SINGLE);
//    ocftFaceDetector.setPaDetectorListener(this);
  }

  //开启预览 开启检测
  @Override protected void onResume() {
    super.onResume();
    ocftFaceDetector.start();
  }

  //暂停预览 暂停检测
  @Override protected void onPause() {
    super.onPause();
    ocftFaceDetector.stop();
  }

  @Override protected void onDestroy() {
    super.onDestroy();
    ocftFaceDetector.destroy();
  }
  @Override public void onOcftDetectTips(int tips) {
    Log.i("FaceDetectActivity", "onOcftDetectTips tips="+tips);
    tv_tips.setText(OcftTips.getDescription(tips));
  }

  @Override
  public void onOcftDetectMotionTips(int motionTip, Map<String, Object> option) {
    Log.i("FaceDetectActivity", "onOcftDetectMotionTips motionTip="+motionTip);
    tv_tips.setText(OcftTips.getDescription(motionTip));
  }

  @Override public void onOcftDetectionSuccess(OcftFaceDetectorResult result) {
    Bitmap originalBitmap = result.getOriginalBitmap();

    Log.i("FaceDetect","originalBitmap.getHeight()="+originalBitmap.getHeight());
    Log.i("FaceDetect","originalBitmap.getWidth()="+originalBitmap.getWidth());
    byte[] bytes = bitmap2Bytes(originalBitmap);
    intent.putExtra("bytes", bytes);
    Location location = result.getLocation();
    if (isLocation) {
      if (location != null) {
        double longitude = location.getLongitude();//经度
        double latitude = location.getLatitude();//纬度
        intent.putExtra("longitude", longitude);
        intent.putExtra("latitude", latitude);
      } else {
        intent.putExtra("longitude", 0.0f);
        intent.putExtra("latitude", 0.0f);
      }
    }
    setResult(2, intent);
    finish();
  }

  @Override public void onOcftDetectionFailed(int tips) {
    Log.i("FaceDetectActivity", "onOcftDetectionFailed tips="+tips);
    tv_tips.setText("请按照提示做出相应动作");
    startTime();
  }

  private void startTime(){
    new Handler().postDelayed(new Runnable() {
      @Override public void run() {
        if(3-time<3){
          tv_tips.setText(time+"秒后重新开启检测");
          startTime();
          time--;
        }else {
          if(time==0){
            time = 3;
            tv_tips.setText("重新开启检测");
            restartDetector();
          }
        }
      }
    },1000);
  }

  private void restartDetector() {
    new Handler().postDelayed(new Runnable(){
      public void run() {
        //重新开启检测需要重新设置
//        ocftFaceDetector.setDetectModes(faceDetectType);
        ocftFaceDetector.start();
      }
    }, 1000);
  }

  private  byte[] bitmap2Bytes(Bitmap bm) {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    bm.compress(Bitmap.CompressFormat.JPEG, 100, baos);
    return baos.toByteArray();
  }

}
