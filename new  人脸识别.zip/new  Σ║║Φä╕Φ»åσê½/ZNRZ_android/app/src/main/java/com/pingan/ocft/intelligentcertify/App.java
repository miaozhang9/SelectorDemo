package com.pingan.ocft.intelligentcertify;

import android.app.Application;

/**
 * Created by luoqianfeng779 on 2017/9/18.
 */

public class App extends Application{

  @Override public void onCreate() {
    super.onCreate();
  }
}
