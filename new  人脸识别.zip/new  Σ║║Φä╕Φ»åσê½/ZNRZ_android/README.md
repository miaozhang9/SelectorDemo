初始化接口
以OcftFaceDetector类作为管理器，负责初始化SDK，暴露正向控制接口，回调函数。

获取摄像头界面

OcftFaceDetectorSurfaceView是摄像头界面,getSurfaceView()获取

开启检测

start(Boolean isLocation)
isLocation = true， 回调函数会包含定位信息
isLocation = false，回调函数不包含定位信息
