//
//  TakePictureAdviseView.h
//  FaceDemo1.3
//
//  Created by tianliang on 2017/8/28.
//  Copyright © 2017年 ZL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TakePictureAdviseView : UIView
@property (nonatomic,strong)UIButton *SureBtn;
@end
