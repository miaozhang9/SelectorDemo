//
//  TakePictureAdviseView.m
//  FaceDemo1.3
//
//  Created by tianliang on 2017/8/28.
//  Copyright © 2017年 ZL. All rights reserved.
//

#import "TakePictureAdviseView.h"
#import "PAZCLDefineTool.h"
@implementation TakePictureAdviseView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self CreateLabel];
        
    }
    return self;
}
- (void)CreateLabel
{

    UIImageView *imageView = [[UIImageView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    imageView.image = [UIImage imageNamed:@"蒙版"];
    
    [self addSubview:imageView];
    
    
    UIView *BottomView = [[UIView alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(20),kScreenHeight_Ratio(94) , kScreenWidth_Ratio(335), kScreenHeight_Ratio(553))];
    BottomView.backgroundColor = [UIColor whiteColor];
    BottomView.layer.cornerRadius = 5;
    BottomView.layer.masksToBounds = YES;
    [self addSubview:BottomView];
    
 // 标题字体大小和高度
    NSInteger TitleFont = 18;
    NSInteger TitleHight = 18;
 // 内容字体大小和高度
    NSInteger ContentFont = 15;
    NSInteger ContentHight = 15;
    if (kScreenWidth == 320) {
        TitleFont = 16;
        TitleHight = 16;
        
        ContentFont = 13;
        ContentHight = 13;
    }
  // 大标题
    UILabel *TitleLabael = [[UILabel alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(106), kScreenHeight_Ratio(22.5), 200, TitleHight)];
    TitleLabael.text = @"拍照要求和建议";
    [TitleLabael setFont:[UIFont systemFontOfSize:TitleFont]];
    [BottomView addSubview:TitleLabael];
    

    float Y = CGRectGetMaxY(TitleLabael.frame) +kScreenHeight_Ratio(20);
    UILabel *OneTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(15), kScreenHeight_Ratio(Y), 200, ContentHight)];
    // — 标题
    OneTitleLabel.text = @"一.证件照拍摄要求";
    [OneTitleLabel setFont:[UIFont systemFontOfSize:ContentFont]];
    [BottomView addSubview:OneTitleLabel];
    
    float OneimageViewY = CGRectGetMaxY(OneTitleLabel.frame) +kScreenHeight_Ratio(15);
    UIImageView *OneimageView = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(34), OneimageViewY, 14, 14)];
    OneimageView.image = [UIImage imageNamed:@"1"];
    [BottomView addSubview:OneimageView];
    
    float ContentOneLabelX = CGRectGetMaxX(OneimageView.frame) +5;
    float ContentOneLabelY = CGRectGetMaxY(OneTitleLabel.frame) +10;
    UILabel *ContentOneLabel = [[UILabel alloc] initWithFrame:CGRectMake(ContentOneLabelX, ContentOneLabelY, kScreenWidth_Ratio(260), ContentFont)];
    ContentOneLabel.text = @"请使用本人的第二代身份证进行拍摄;";
    [ContentOneLabel setFont:[UIFont systemFontOfSize:ContentHight]];
    [BottomView addSubview:ContentOneLabel];
    
    float TwoimageViewY = CGRectGetMaxY(ContentOneLabel.frame) +kScreenHeight_Ratio(15);
    UIImageView *TwoimageView = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(34), TwoimageViewY, 14, 14)];
    TwoimageView.image = [UIImage imageNamed:@"2"];
    [BottomView addSubview:TwoimageView];
    
    float ContentTwoLabelX = CGRectGetMaxX(TwoimageView.frame) +5;
    float ContentTwoLabelY = CGRectGetMaxY(ContentOneLabel.frame) +10;
    UILabel *ContentTwoLabel = [[UILabel alloc] initWithFrame:CGRectMake(ContentTwoLabelX, ContentTwoLabelY, kScreenWidth_Ratio(260), ContentHight*2+7)];
    ContentTwoLabel.text = @"请保持身份证人像面及国徽面字迹清晰完整,无破损;";
    
    [ContentTwoLabel setFont:[UIFont systemFontOfSize:ContentFont]];
    ContentTwoLabel.numberOfLines = 0;
    [BottomView addSubview:ContentTwoLabel];
    
    
    float ThreeimageViewY = CGRectGetMaxY(ContentTwoLabel.frame) +kScreenHeight_Ratio(15);
    UIImageView *ThreeimageView = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(34), ThreeimageViewY, 14, 14)];
    ThreeimageView.image = [UIImage imageNamed:@"3"];
    [BottomView addSubview:ThreeimageView];
    
    float ContentThreeLabelX = CGRectGetMaxX(ThreeimageView.frame) +5;
    float ContentThreeLabelY = CGRectGetMaxY(ContentTwoLabel.frame) +10;
    UILabel *ContentThreeLabel = [[UILabel alloc] initWithFrame:CGRectMake(ContentThreeLabelX, ContentThreeLabelY, kScreenWidth_Ratio(260), ContentHight*2+7)];
    ContentThreeLabel.text = @"请保持光线充足，拍摄时身份证上的字迹不要有阴影和反光;";
    
    [ContentThreeLabel setFont:[UIFont systemFontOfSize:ContentFont]];
    ContentThreeLabel.numberOfLines = 0;
    [BottomView addSubview:ContentThreeLabel];
    
    float FourimageViewY = CGRectGetMaxY(ContentThreeLabel.frame) +kScreenHeight_Ratio(12);
    UIImageView *FourimageView = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(34), FourimageViewY, 14, 14)];
    FourimageView.image = [UIImage imageNamed:@"4"];
    [BottomView addSubview:FourimageView];
    
    float ContentFourLabelX = CGRectGetMaxX(ThreeimageView.frame) +5;
    float ContentFourLabelY = CGRectGetMaxY(ContentThreeLabel.frame) +10;
    UILabel *ContentFourLabel = [[UILabel alloc] initWithFrame:CGRectMake(ContentFourLabelX, ContentFourLabelY, kScreenWidth_Ratio(260), ContentHight)];
    ContentFourLabel.text = @"请保持身份证和银行卡照在采集框内;";
    
    [ContentFourLabel setFont:[UIFont systemFontOfSize:ContentFont]];
    ContentFourLabel.numberOfLines = 0;
    [BottomView addSubview:ContentFourLabel];
    
    
    float TwoTitleLabelY = CGRectGetMaxY(ContentFourLabel.frame) +kScreenHeight_Ratio(20);
    UILabel *TwoTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(15), TwoTitleLabelY, 200, ContentHight)];
    // — 标题
    TwoTitleLabel.text = @"二.证件照拍摄要求";
    [TwoTitleLabel setFont:[UIFont systemFontOfSize:ContentFont]];
    [BottomView addSubview:TwoTitleLabel];
    
    float TwoTitleOneimageViewY = CGRectGetMaxY(TwoTitleLabel.frame) +kScreenHeight_Ratio(13);
    UIImageView *TwoTitleOneimageView = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(34), TwoTitleOneimageViewY, 14, 14)];
    TwoTitleOneimageView.image = [UIImage imageNamed:@"1"];
    [BottomView addSubview:TwoTitleOneimageView];
    
    float TwoTitleContentOneLabelX = CGRectGetMaxX(TwoTitleOneimageView.frame) +5;
    float TwoTitleContentOneLabelY = CGRectGetMaxY(TwoTitleLabel.frame) +kScreenHeight_Ratio(10);
    UILabel *TwoTitleContentOneLabel = [[UILabel alloc] initWithFrame:CGRectMake(TwoTitleContentOneLabelX, TwoTitleContentOneLabelY, kScreenWidth_Ratio(260), ContentHight)];
    TwoTitleContentOneLabel.text = @"拍摄人脸过程中请勿晃动";;
    [TwoTitleContentOneLabel setFont:[UIFont systemFontOfSize:ContentFont]];
    [BottomView addSubview:TwoTitleContentOneLabel];
    
    
    float TwoTitleTwoimageViewY = CGRectGetMaxY(TwoTitleContentOneLabel.frame) +kScreenHeight_Ratio(15);
    UIImageView *TwoTitleTwoimageView = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(34), TwoTitleTwoimageViewY, 14, 14)];
    TwoTitleTwoimageView.image = [UIImage imageNamed:@"2"];
    [BottomView addSubview:TwoTitleTwoimageView];
    
    float TwoTitleOneContentOneLabelX = CGRectGetMaxX(TwoTitleOneimageView.frame) +5;
    float TwoTitleOneContentOneLabelY = CGRectGetMaxY(TwoTitleContentOneLabel.frame) +kScreenHeight_Ratio(10);
    UILabel *TwoTitleOneContentOneLabel = [[UILabel alloc] initWithFrame:CGRectMake(TwoTitleOneContentOneLabelX, TwoTitleOneContentOneLabelY, kScreenWidth_Ratio(260), ContentHight*2+7)];
    TwoTitleOneContentOneLabel.text = @"请保持拍摄环境光线充足,人脸正对摄像头;";;
    [TwoTitleOneContentOneLabel setFont:[UIFont systemFontOfSize:ContentFont]];
    TwoTitleOneContentOneLabel.numberOfLines = 0;
    [BottomView addSubview:TwoTitleOneContentOneLabel];
    
    
    float TwoTitleThreeimageViewY = CGRectGetMaxY(TwoTitleOneContentOneLabel.frame) +kScreenHeight_Ratio(12);
    UIImageView *TwoTitleThreeimageView = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(34), TwoTitleThreeimageViewY, 14, 14)];
    TwoTitleThreeimageView.image = [UIImage imageNamed:@"3"];
    [BottomView addSubview:TwoTitleThreeimageView];
    
    float TwoTitleThreeContentOneLabelX = CGRectGetMaxX(TwoTitleThreeimageView.frame) +5;
    float TwoTitleThreeContentOneLabelY = CGRectGetMaxY(TwoTitleOneContentOneLabel.frame) +kScreenHeight_Ratio(10);
    UILabel *TwoTitleThreeContentOneLabel = [[UILabel alloc] initWithFrame:CGRectMake(TwoTitleThreeContentOneLabelX, TwoTitleThreeContentOneLabelY, kScreenWidth_Ratio(260), ContentHight)];
    TwoTitleThreeContentOneLabel.text = @"拍摄时请不要持浓妆;";;
    [TwoTitleThreeContentOneLabel setFont:[UIFont systemFontOfSize:ContentFont]];
    [BottomView addSubview:TwoTitleThreeContentOneLabel];
    
    // — 标题
    float ThreeTitleLabelY = CGRectGetMaxY(TwoTitleThreeContentOneLabel.frame) +kScreenHeight_Ratio(20);
    UILabel *ThreeTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(15), ThreeTitleLabelY, 200, ContentHight)];
    ThreeTitleLabel.text = @"三.错误示例";
    [ThreeTitleLabel setFont:[UIFont systemFontOfSize:ContentFont]];
    [BottomView addSubview:ThreeTitleLabel];
    
    float OneImageViewY =CGRectGetMaxY(ThreeTitleLabel.frame) +kScreenHeight_Ratio(10);
    UIImageView *OneImageView = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(35), OneImageViewY, kScreenWidth_Ratio(62), kScreenWidth_Ratio(79))];
    OneImageView.image = [UIImage imageNamed:@"11"];
    [BottomView addSubview:OneImageView];

    float TwoImageViewX =CGRectGetMaxX(OneImageView.frame) +kScreenHeight_Ratio(35);
    UIImageView *TwoImageView = [[UIImageView alloc] initWithFrame:CGRectMake(TwoImageViewX, OneImageViewY, kScreenWidth_Ratio(62), kScreenWidth_Ratio(79))];
    TwoImageView.image = [UIImage imageNamed:@"22"];
    [BottomView addSubview:TwoImageView];
    
    float ThreeImageViewX =CGRectGetMaxX(TwoImageView.frame) +kScreenHeight_Ratio(35);
    UIImageView *ThreeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(ThreeImageViewX, OneImageViewY, kScreenWidth_Ratio(62), kScreenWidth_Ratio(79))];
    ThreeImageView.image = [UIImage imageNamed:@"33"];
    [BottomView addSubview:ThreeImageView];
    
    // 横线
    float lineViewY =CGRectGetMaxY(TwoImageView.frame) +kScreenHeight_Ratio(20);
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, lineViewY, kScreenWidth, 1)];
    lineView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [BottomView addSubview:lineView];
    
    // Btn
    float SureBtnY =CGRectGetMaxY(lineView.frame);
    self.SureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.SureBtn.frame = CGRectMake(0, SureBtnY, kScreenWidth_Ratio(335), kScreenHeight_Ratio(54));
    [self.SureBtn setTitle:@"知道了" forState:UIControlStateNormal];
    [self.SureBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
    [BottomView addSubview:self.SureBtn];
    


}
@end
