//
//  HomeViewController.m
//  FOSDemo
//
//  Created by 周宗锂(AI产品应用团队AI工程化开发组) on 2017/9/12.
//  Copyright © 2017年 周宗锂(AI产品应用团队AI工程化开发组). All rights reserved.
//

#import "HomeViewController.h"
#import "FaceDectorViewController.h"
#import "ViewController.h"
#import "TakePictureAdviseView.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <Photos/PHPhotoLibrary.h>
#import <OCFTFaceDetect/OCFTFaceDetector.h>


#import "PAOCRHandle.h"
#import "HV2APIManager.h"
#import "PACardCheckHandle.h"
#import "ResultViewController.h"
#import "SVProgressHUD.h"
#import "PAMarkView.h"

@interface HomeViewController ()<OCRDetectorDelegate,faceDetectorDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UITextField *cardNumberTextField;
@property (weak, nonatomic) IBOutlet UIImageView *faceImage;
@property (weak, nonatomic) IBOutlet UILabel *weidu1;
@property (weak, nonatomic) IBOutlet UILabel *jingdu1;
@property (weak, nonatomic) IBOutlet UILabel *weidu2;
@property (weak, nonatomic) IBOutlet UILabel *jingdu2;
@property (weak, nonatomic) IBOutlet UIImageView *image1;
@property (weak, nonatomic) IBOutlet UIImageView *image2;
@property (weak, nonatomic) IBOutlet UIButton *cardCompare;
@property (weak, nonatomic) IBOutlet UIButton *faceCompare;

@property (weak, nonatomic) IBOutlet UISwitch *switchBtn;
@property (nonatomic, assign) NSInteger imageViewNmuber;
@property (weak, nonatomic) IBOutlet UISegmentedControl *chooseActionSegment;


@property (nonatomic , strong)PAMarkView *MarkView; // 拍照需求
@property (nonatomic, strong) UIImagePickerController *imagePickerController;


@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UITapGestureRecognizer *tapGesturRecognizer1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(imageView1DidTap:)];
    UITapGestureRecognizer *tapGesturRecognizer2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(imageView2DidTap:)];
    [self.image1 addGestureRecognizer:tapGesturRecognizer1];
//    [self.image2 addGestureRecognizer:tapGesturRecognizer2];
    self.imagePickerController = [[UIImagePickerController alloc] init];
    self.imagePickerController.delegate = self;
    self.imagePickerController.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    self.imagePickerController.allowsEditing = YES;
    
    [self.image1 addObserver:self forKeyPath:@"image" options:NSKeyValueObservingOptionNew |NSKeyValueObservingOptionOld context:nil];
    [self.image2 addObserver:self forKeyPath:@"image" options:NSKeyValueObservingOptionNew |NSKeyValueObservingOptionOld context:nil];
    [self.cardNumberTextField addObserver:self forKeyPath:@"text" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:nil];
    
}


-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    if([keyPath isEqualToString:@"image"] && object == self.image1  ) {
        if ([change valueForKey:@"new"] != nil && ![self.cardNumberTextField.text isEqualToString:@""]) {
            self.cardCompare.enabled = YES;
        }
        if ([change valueForKey:@"new"] != nil && self.image2.image != nil) {
            self.faceCompare.enabled = YES;
        }
        
    }
    if ([keyPath isEqualToString: @"image"] && object == self.image2) {
        if ([change valueForKey:@"new"] != nil && self.image1.image != nil ) {
            self.faceCompare.enabled = YES;
        }
        
    }
    
    if ([keyPath isEqualToString:@"text"] && object == self.cardNumberTextField) {
        if (![[change valueForKey:@"new"] isEqualToString:@""] && self.image1.image != nil ) {
            self.cardCompare.enabled = YES;
        }
    }
}

-(void)imageView1DidTap:(id )sender {
    NSLog(@"%@",sender);
    self.imageViewNmuber = 11;
    FaceDectorViewController *faceDetectorVC = [[FaceDectorViewController alloc] init];
    faceDetectorVC.delegate = self;
    faceDetectorVC.GPS = self.switchBtn.on;
    unsigned long actionTypeNum = [self.chooseActionSegment selectedSegmentIndex] + 1;
    NSString *actionType = [NSString stringWithFormat:@"%lu", actionTypeNum];
    faceDetectorVC.actionType = actionType;
    [self.navigationController pushViewController:faceDetectorVC animated:YES];
}

-(void)imageView2DidTap:(id )sender {
    NSLog(@"%@",sender);
    self.imageViewNmuber = 22;
    FaceDectorViewController *faceDetectorVC = [[FaceDectorViewController alloc] init];
    faceDetectorVC.delegate = self;
    faceDetectorVC.GPS = self.switchBtn.on;
    [self.navigationController pushViewController:faceDetectorVC animated:YES];
    
}
#pragma mark - action

- (IBAction)tipAction:(id)sender {
    PAMarkView *MarkView = [[PAMarkView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    [MarkView.SureBtn addTarget:self action:@selector(ShowHidden:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view insertSubview:MarkView atIndex:0];
    
    [self.view bringSubviewToFront:MarkView];
    self.MarkView = MarkView;
    
}

- (IBAction)OCRaction:(id)sender {
    ViewController *OCRVC = [[ViewController alloc] init];
    OCRVC.delegate = self;
    [self.navigationController pushViewController:OCRVC animated:YES];
    //    [self selectImageFromCamera];
}

- (IBAction)faceCompareWithFace:(id)sender {
    if (self.image1.image && self.image2.image) {
        [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
        __block ResultViewController *v = [[ResultViewController alloc] init];
        [[HV2APIManager shareInstance] biolDetectWithImage:self.image1.image success:^(id responseObject) {
            NSLog(@"left :%@",responseObject);
            dispatch_async(dispatch_get_main_queue(), ^{
                if (responseObject[@"is_alive"]) {
                    v.resultLabel1.text = @"是活体";
                }else{
                    v.resultLabel1.text = @"非活体";
                }
                
            });
            [[HV2APIManager shareInstance] biolDetectWithImage:self.image2.image success:^(id responseObject) {
                NSLog(@"right :%@",responseObject);
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (responseObject[@"is_alive"]) {
                        v.resultLabel2.text = @"是活体";
                    }else{
                        v.resultLabel2.text = @"非活体";
                    }
                    
                });
                [[HV2APIManager shareInstance] compareWithImage1:self.image1.image image2:self.image2.image success:^(id responseObject) {
                    NSLog(@"face  :%@",responseObject);
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        v.resultLabel3.text = responseObject[@"ref_thres"];
                        v.resultLabel4.text =   [responseObject[@"similarity"] substringToIndex:5];
                        [SVProgressHUD dismiss];
                        [self.navigationController pushViewController:v animated:YES];
                        
                    });
                } failure:^(NSError *error) {
                    
                }];
            } failure:^(NSError *error) {
                
            }];
        } failure:^(NSError *error) {
            
        }];
        
        
    }
}

- (IBAction)CardCompareWithFace:(id)sender {
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
    __block ResultViewController *v = [[ResultViewController alloc] init];

    [[PACardCheckHandle shareInstance] faceCheckWithImage:self.image1.image name:self.nameTextField.text cardID:self.cardNumberTextField.text success:^(id responseObject) {
        NSLog(@"card :%@",responseObject);
        dispatch_async(dispatch_get_main_queue(), ^{
            v.resultLabel3.text = responseObject[@"data"][@"ref_thres"];
            v.resultLabel4.text = [responseObject[@"data"][@"similarity"] substringToIndex:5];
        });
        [[HV2APIManager shareInstance] biolDetectWithImage:self.image1.image success:^(id responseObject) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (responseObject[@"is_alive"]) {
                    v.resultLabel2.text = @"是活体";
                }else{
                    v.resultLabel2.text = @"非活体";
                }
                [SVProgressHUD dismiss];
                [self.navigationController pushViewController:v animated:YES];
                

            });
        } failure:^(NSError *error) {
            
        }];
    } failure:^(NSError *error) {
        
    }];
}

- (void)ShowHidden:(UIButton *)sureBtn
{
    [self.MarkView removeFromSuperview];
    
}


- (void)selectImageFromCamera {
    _imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
    _imagePickerController.cameraDevice = UIImagePickerControllerCameraDeviceFront;
    _imagePickerController.mediaTypes = @[(NSString *)kUTTypeImage];
    _imagePickerController.cameraCaptureMode = UIImagePickerControllerCameraCaptureModePhoto;
    
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    
    if(authStatus == AVAuthorizationStatusAuthorized)
    {
        [self presentViewController:_imagePickerController animated:YES completion:nil];
    }
    else if (authStatus == AVAuthorizationStatusDenied)
    {
        UIAlertView *alertV = [[UIAlertView alloc] initWithTitle:@"Tips" message:@"Please access the camera in the device's settings privacy camera" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alertV show];
    }
    else if (authStatus == AVAuthorizationStatusNotDetermined)
    {
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
            if (granted) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self presentViewController:_imagePickerController animated:YES completion:nil];
                });
            }else{
                
            }
        }];
    }
    
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info {
    
    NSString *mediaType=[info objectForKey:UIImagePickerControllerMediaType];
    //判断资源类型
    if ([mediaType isEqualToString:(NSString *)kUTTypeImage]){
        UIImage *image = info[UIImagePickerControllerEditedImage];
        [[PAOCRHandle shareInstance] getInformationWithImage:image cardType:PAOCRCheckCardType_ID_II_Front success:^(id responseObject) {
            NSLog(@"responseObject:%@",responseObject);
            
            
            
        } failure:^(NSError *error) {
            
        }];
        
    }else{
        //video
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma - DELEGATE

-(void)didCheckFace:(id)faceInfo {
    
    UIImage *image = ((OCFTFaceDetectionFrame*)faceInfo).headImage;
    NSString *jingdu =((OCFTFaceDetectionFrame*)faceInfo).locationInfo[@"经度"];
    NSString *weidu =((OCFTFaceDetectionFrame*)faceInfo).locationInfo[@"纬度"];
    switch (self.imageViewNmuber) {
        case 11:
            self.image1.image = image;
            self.jingdu1.text = [NSString stringWithFormat:@"经度：%@",jingdu];
            self.weidu1.text = [NSString stringWithFormat:@"纬度：%@",weidu];
            break;
        case 22:
            self.image2.image = image;
            self.jingdu2.text = [NSString stringWithFormat:@"经度：%@",jingdu];
            self.weidu2.text = [NSString stringWithFormat:@"纬度：%@",weidu];
            
            break;
        default:
            break;
    }
    
}

-(void)didCheckCard:(id)cardInfo {
    self.nameTextField.text = ((NSDictionary *)cardInfo)[@"name"];
    self.cardNumberTextField.text = ((NSDictionary *)cardInfo)[@"number"];
    
}

@end
