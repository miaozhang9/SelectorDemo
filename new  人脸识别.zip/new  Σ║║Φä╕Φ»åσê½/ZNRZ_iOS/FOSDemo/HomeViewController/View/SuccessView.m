//
//  SuccessView.m
//  FOSDemo
//
//  Created by 周宗锂(AI产品应用团队AI工程化开发组) on 2017/9/14.
//  Copyright © 2017年 周宗锂(AI产品应用团队AI工程化开发组). All rights reserved.
//

#import "SuccessView.h"
#import "PAZCLDefineTool.h"
#import "UIView+ViewFrameGeometry.h"


@implementation SuccessView



-(instancetype)init {
    self = [super init];
    if (self) {
        
        self.frame = [UIScreen mainScreen].bounds;
        self.cheakLabel1 = [[UILabel alloc] init];
        self.cheakLabel1.textAlignment = NSTextAlignmentRight;
        self.cheakLabel1.frame = CGRectMake(kScreenWidth/4, 230, kScreenWidth/4, 56);
        self.cheakLabel1.font = [UIFont systemFontOfSize:23];
        self.cheakLabel1.textColor = [UIColor grayColor];
        self.cheakLabel1.backgroundColor = [UIColor blueColor];
        self.cheakLabel1.text = @"右活体:";
        self.cheakLabel1.numberOfLines = 0;
        self.cheakLabel1.lineBreakMode = NSLineBreakByWordWrapping;
        [self addSubview:self.cheakLabel1];
        
        self.resultLabel1 = [[UILabel alloc] init];
        self.resultLabel1.textAlignment = NSTextAlignmentLeft;
        self.resultLabel1.frame = CGRectMake(self.cheakLabel1.right, self.cheakLabel1.top, kScreenWidth/4, 56);
        self.resultLabel1.font = [UIFont systemFontOfSize:23];
        self.resultLabel1.textColor = [UIColor grayColor];
        self.resultLabel1.backgroundColor = [UIColor blueColor];
        self.resultLabel1.text = @"";
        self.resultLabel1.numberOfLines = 0;
        self.resultLabel1.lineBreakMode = NSLineBreakByWordWrapping;
        [self addSubview:self.resultLabel1];
        
        self.cheakLabel2 = [[UILabel alloc] init];
        self.cheakLabel2.textAlignment = NSTextAlignmentRight;
        self.cheakLabel2.frame = CGRectMake(kScreenWidth/4, self.cheakLabel1.bottom + 10, kScreenWidth/4, 56);
        self.cheakLabel2.font = [UIFont systemFontOfSize:23];
        self.cheakLabel2.textColor = [UIColor grayColor];
        self.cheakLabel2.backgroundColor = [UIColor blueColor];
        self.cheakLabel2.text = @"左活体:";
        self.cheakLabel2.numberOfLines = 0;
        self.cheakLabel2.lineBreakMode = NSLineBreakByWordWrapping;
        [self addSubview:self.cheakLabel2];
        
        self.resultLabel2 = [[UILabel alloc] init];
        self.resultLabel2.textAlignment = NSTextAlignmentLeft;
        self.resultLabel2.frame = CGRectMake(self.cheakLabel2.right, self.cheakLabel1.bottom + 10, kScreenWidth/4, 56);
        self.resultLabel2.font = [UIFont systemFontOfSize:23];
        self.resultLabel2.textColor = [UIColor grayColor];
        self.resultLabel2.backgroundColor = [UIColor blueColor];
        self.resultLabel2.text = @"";
        self.resultLabel2.numberOfLines = 0;
        self.resultLabel2.lineBreakMode = NSLineBreakByWordWrapping;
        [self addSubview:self.resultLabel2];
        
        self.cheakLabel3 = [[UILabel alloc] init];
        self.cheakLabel3.textAlignment = NSTextAlignmentRight;
        self.cheakLabel3.frame = CGRectMake(kScreenWidth/4, self.cheakLabel2.bottom + 10, kScreenWidth/4, 56);
        self.cheakLabel3.font = [UIFont systemFontOfSize:23];
        self.cheakLabel3.textColor = [UIColor grayColor];
        self.cheakLabel3.backgroundColor = [UIColor blueColor];
        self.cheakLabel3.text = @"建议阈值:";
        self.cheakLabel3.numberOfLines = 0;
        self.cheakLabel3.lineBreakMode = NSLineBreakByWordWrapping;
        [self addSubview:self.cheakLabel3];
        
        self.resultLabel3 = [[UILabel alloc] init];
        self.resultLabel3.textAlignment = NSTextAlignmentLeft;
        self.resultLabel3.frame = CGRectMake(self.cheakLabel3.right, self.cheakLabel2.bottom + 10, kScreenWidth/4, 56);
        self.resultLabel3.font = [UIFont systemFontOfSize:23];
        self.resultLabel3.textColor = [UIColor grayColor];
        self.resultLabel3.backgroundColor = [UIColor blueColor];
        self.resultLabel3.text = @"";
        self.resultLabel3.numberOfLines = 0;
        self.resultLabel3.lineBreakMode = NSLineBreakByWordWrapping;
        [self addSubview:self.resultLabel3];
        
        self.cheakLabel4 = [[UILabel alloc] init];
        self.cheakLabel4.textAlignment = NSTextAlignmentRight;
        self.cheakLabel4.frame = CGRectMake(kScreenWidth/4, self.cheakLabel3.bottom + 10, kScreenWidth/4, 56);
        self.cheakLabel4.font = [UIFont systemFontOfSize:23];
        self.cheakLabel4.textColor = [UIColor grayColor];
        self.cheakLabel4.backgroundColor = [UIColor blueColor];
        self.cheakLabel4.text = @"相似度:";
        self.cheakLabel4.numberOfLines = 0;
        self.cheakLabel4.lineBreakMode = NSLineBreakByWordWrapping;
        [self addSubview:self.cheakLabel4];
        
        self.resultLabel4 = [[UILabel alloc] init];
        self.resultLabel4.textAlignment = NSTextAlignmentLeft;
        self.resultLabel4.frame = CGRectMake(self.cheakLabel4.right, self.cheakLabel3.bottom + 10, kScreenWidth/4, 56);
        self.resultLabel4.font = [UIFont systemFontOfSize:23];
        self.resultLabel4.textColor = [UIColor grayColor];
        self.resultLabel4.backgroundColor = [UIColor blueColor];
        self.resultLabel4.text = @"";
        self.resultLabel4.numberOfLines = 0;
        self.resultLabel4.lineBreakMode = NSLineBreakByWordWrapping;
        [self addSubview:self.resultLabel4];
        
        self.backgroundColor = [UIColor whiteColor];

    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
