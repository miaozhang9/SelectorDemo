//
//  SuccessView.h
//  FOSDemo
//
//  Created by 周宗锂(AI产品应用团队AI工程化开发组) on 2017/9/14.
//  Copyright © 2017年 周宗锂(AI产品应用团队AI工程化开发组). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SuccessView : UIView
@property (strong, nonatomic) UILabel *cheakLabel1;
@property (strong, nonatomic) UILabel *resultLabel1;


@property (strong, nonatomic) UILabel *cheakLabel2;
@property (strong, nonatomic) UILabel *resultLabel2;

@property (strong, nonatomic) UILabel *cheakLabel3;
@property (strong, nonatomic) UILabel *resultLabel3;

@property (strong, nonatomic) UILabel *cheakLabel4;
@property (strong, nonatomic) UILabel *resultLabel4;

@end
