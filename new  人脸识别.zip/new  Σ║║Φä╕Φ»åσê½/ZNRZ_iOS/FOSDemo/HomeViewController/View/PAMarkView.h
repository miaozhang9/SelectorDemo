//
//  PAMarkView.h
//  FaceDemo1.3
//
//  Created by tianliang on 2017/9/7.
//  Copyright © 2017年 ZL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PAMarkView : UIView
@property (nonatomic,strong)UIButton *SureBtn;
@end
