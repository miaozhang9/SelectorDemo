//
//  PAMarkView.m
//  FaceDemo1.3
//
//  Created by tianliang on 2017/9/7.
//  Copyright © 2017年 ZL. All rights reserved.
//

#import "PAMarkView.h"
#import "PAZCLDefineTool.h"

@implementation PAMarkView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self CreateContent];
    }
    return self;
}

- (void)CreateContent
{
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    imageView.image = [UIImage imageNamed:@"蒙版"];
    
    [self addSubview:imageView];

    UIView *BottomView = [[UIView alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(20),kScreenHeight_Ratio(186) , kScreenWidth_Ratio(335), kScreenHeight_Ratio(358))];
    BottomView.backgroundColor = [UIColor whiteColor];
    BottomView.layer.cornerRadius = 5;
    BottomView.layer.masksToBounds = YES;
    [self addSubview:BottomView];
    
    
    // 标题字体大小和高度
    NSInteger TitleFont = 18;
    NSInteger TitleHight = 18;
    // 内容字体大小和高度
    NSInteger ContentFont = 15;
    NSInteger ContentHight = 15;
    if (kScreenWidth == 320) {
        TitleFont = 16;
        TitleHight = 16;
        
        ContentFont = 13;
        ContentHight = 13;
    }
    // 大标题
    UILabel *TitleLabael = [[UILabel alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(132), kScreenHeight_Ratio(23), 200, TitleHight)];
    TitleLabael.text = @"拍照要求";
    [TitleLabael setFont:[UIFont systemFontOfSize:TitleFont]];
    [BottomView addSubview:TitleLabael];

    
    
    float OneimageViewY = CGRectGetMaxY(TitleLabael.frame) +kScreenHeight_Ratio(30);
    UIImageView *OneimageView = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(41), OneimageViewY, 45, 45)];
    OneimageView.image = [UIImage imageNamed:@"正对手机@2x.png"];
    [BottomView addSubview:OneimageView];
    
    float Y = CGRectGetMaxY(TitleLabael.frame) +kScreenHeight_Ratio(30);
    UILabel *OneTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(OneimageView.frame)+19, kScreenHeight_Ratio(Y), 200, 45)];
    // — 标题
    OneTitleLabel.text = @"请保持人脸正对手机";
    [OneTitleLabel setFont:[UIFont systemFontOfSize:ContentFont]];
    [OneTitleLabel setTextColor:[UIColor darkGrayColor]];
    [BottomView addSubview:OneTitleLabel];
    
    
    float TwoimageViewY = CGRectGetMaxY(OneimageView.frame) +kScreenHeight_Ratio(30);
    UIImageView *TwoimageView = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(41), TwoimageViewY, 45, 45)];
    TwoimageView.image = [UIImage imageNamed:@"_不带帽子@2x.png"];
    [BottomView addSubview:TwoimageView];
    
    float TwoTitleLabelY = CGRectGetMaxY(OneimageView.frame) +kScreenHeight_Ratio(30);
    UILabel *TwoTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(OneimageView.frame)+19, kScreenHeight_Ratio(TwoTitleLabelY), 200, 45)];
    // — 标题
    TwoTitleLabel.text = @"拍摄时请不要戴眼镜和帽子";
    [TwoTitleLabel setFont:[UIFont systemFontOfSize:ContentFont]];
    [TwoTitleLabel setTextColor:[UIColor darkGrayColor]];

    [BottomView addSubview:TwoTitleLabel];
    
    
    
    float ThreeimageViewY = CGRectGetMaxY(TwoimageView.frame) +kScreenHeight_Ratio(30);
    UIImageView *ThreeimageView = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth_Ratio(41), ThreeimageViewY, 45, 45)];
    ThreeimageView.image = [UIImage imageNamed:@"阳光充足@2x.png"];
    [BottomView addSubview:ThreeimageView];
    
    float ThreeTitleLabelY = CGRectGetMaxY(TwoimageView.frame) +kScreenHeight_Ratio(30);
    UILabel *ThreeTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(TwoimageView.frame)+19, kScreenHeight_Ratio(ThreeTitleLabelY), 200, 45)];
    // — 标题
    ThreeTitleLabel.text = @"请保持光照充足,不要在强光弱光下拍摄";
    [ThreeTitleLabel setFont:[UIFont systemFontOfSize:ContentFont]];
    ThreeTitleLabel.numberOfLines = 0;
    [ThreeTitleLabel setTextColor:[UIColor darkGrayColor]];

    [BottomView addSubview:ThreeTitleLabel];
    
    // 横线
    float lineViewY =CGRectGetMaxY(ThreeimageView.frame) +kScreenHeight_Ratio(38);
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, lineViewY, kScreenWidth, 1)];
    lineView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [BottomView addSubview:lineView];
    
    // Btn
    float SureBtnY =CGRectGetMaxY(lineView.frame);
    self.SureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.SureBtn.frame = CGRectMake(0, SureBtnY, kScreenWidth_Ratio(335), kScreenHeight_Ratio(54));
    [self.SureBtn setTitle:@"知道了" forState:UIControlStateNormal];
    [self.SureBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
    [BottomView addSubview:self.SureBtn];
}
@end
