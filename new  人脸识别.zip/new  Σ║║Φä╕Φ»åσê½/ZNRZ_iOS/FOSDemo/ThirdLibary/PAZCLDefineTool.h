//
//  PAZCLDefineTool.h
//  PAFaceCheck
//
//  Created by prliu on 16/3/22.
//  Copyright © 2016年 pingan. All rights reserved.
//

#ifndef PAZCLDefineTool_h
#define PAZCLDefineTool_h

#ifndef PAFacecheckController_ZCLDefineTool_h
#define PAFacecheckController_ZCLDefineTool_h
#define KFINISHMOUTHCHECK @"MouthCheck_finish"//Open mouth
#define KFINISHHEADCHECK @"HeadShake_finish"//Shake head
#define KFINISHFACECHECK @"FaceCheck_finish"//Face detection
#define KFINISHAPICHECK @"api_finish"//Program end


#define KWidth_IPHONE_6P    414.f
#define KHeight_IPHONE_6P   736.f

#define KWidth_IPHONE_6     375.f
#define KHeight_IPHONE_6    667.f

#define KWidth_IPHONE_5     320.f
#define KHeight_IPHONE_5    568.f

#define KWidth_IPHONE_4     320.f
#define KHeight_IPHONE_4    480.f

// CGRectGetMaxY

#define kScreenWidth_Ratio(x)   kScreenWidth  * x / KWidth_IPHONE_6
#define kScreenHeight_Ratio(y)   kScreenHeight * y / KHeight_IPHONE_6

#define F_Ratio(f)   (SCREEN_WIDTH * SCREEN_HEIGHT * f / (KWidth_IPHONE_6 * KHeight_IPHONE_6))

//RGB color
#define kRGBColor(R,G,B,A)    [UIColor colorWithRed:R / 255.0 green:G / 255.0 blue:B / 255.0 alpha:A]

#define kHEXColor(s)          [UIColor colorWithRed:(((s & 0xFF0000) >> 16))/255.0 green:(((s &0xFF00) >>8))/255.0 blue:((s &0xFF))/255.0 alpha:1.0]


//FUNC
#define LOGFUN NSLog(@"----%s----",__func__);


// view rounded corners and borders
#define kViewBorderRadius(View, Radius, Width, Color)\
[View.layer setCornerRadius:(Radius)];\
[View.layer setMasksToBounds:YES];\
[View.layer setBorderWidth:(Width)];\
[View.layer setBorderColor:[Color CGColor]]

#define BACK_GCD(block) dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), block)
#define MAIN_GCD(block)\
if ([NSThread isMainThread]) {\
block();\
} else {\
dispatch_async(dispatch_get_main_queue(), block);\
}


//Picture cache path
#define kImagePathPre  [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"Caches"]

#define kRegistImagePathPre  [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"RegistImages"]
#define kCurrentImagePathPre  [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]



#define KArc4random(maxNumber) arc4random() % (maxNumber + 1)

#define KArc4randomRange(minNumber, maxNumber) minNumber + (arc4random() % (maxNumber - minNumber + 1))





//Live detection time (default is 10)
#define kActionTime 15

#define kFaceImage(name)   [UIImage imageNamed:name]
#define kFaceFilePath(path,type)   [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"myface.bundle/%@", path] ofType:type]


// Random color
#define DRandomColor [UIColor colorWithRed:arc4random_uniform(255)/255.0 green:arc4random_uniform(255)/255.0 blue:arc4random_uniform(255)/255.0 alpha:arc4random_uniform(255)/255.0]

#define kTextColor [UIColor colorWithRed:93/255. green:88/255. blue:88/255. alpha:1.]

#define BACK_ACTION(block) dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), block)
#define MAIN_ACTION(block) dispatch_async(dispatch_get_main_queue(),block)

/* --------------------------------------------------------------------------------- */
#pragma mark - Screen adaptation

// 480  568  667  736
#define kIphone4 (480.0 == [[UIScreen mainScreen] bounds].size.height)
#define kIphone5 (568.0 == [UIScreen mainScreen].bounds.size.height)
#define kIphone6 (667.0 == [UIScreen mainScreen].bounds.size.height)
#define kIphone6p (736.0 == [UIScreen mainScreen].bounds.size.height)

#define kIOSVersions [[[UIDevice currentDevice] systemVersion] floatValue]
#define kUIWindow    [[[UIApplication sharedApplication] delegate] window]

#define kUnderStatusBarStartY (kIOSVersions>=7.0 ? 20 : 0)                 

#define kScreenSize           [[UIScreen mainScreen] bounds].size                 //(e.g. 320,480)
#define kScreenWidth          [[UIScreen mainScreen] bounds].size.width           //(e.g. 320)
#define kScreenHeight         [[UIScreen mainScreen] bounds].size.height          //(e.g. 480)
#define kScreenHeightIOS7  (kIOSVersions>=7.0 ? [[UIScreen mainScreen] bounds].size.height + 64 : [[UIScreen mainScreen] bounds].size.height)

#define kScaleWidth(width)      ((width)*kScreenWidth)/320    //Screen width adaptation
#define kScaleHeight(height)   (kIphone4?(height):((height)*kScreenHeight)/568)    //Screen height Adaptation

#define kIOS7OffHeight (kIOSVersions>=7.0 ? 64 : 0)

#define kApplicationSize      [[UIScreen mainScreen] applicationFrame].size       //(e.g. 320,460)
#define kApplicationWidth     [[UIScreen mainScreen] applicationFrame].size.width //(e.g. 320)
#define kApplicationHeight    [[UIScreen mainScreen] applicationFrame].size.height//The screen height does not contain the height of the status bar(e.g. 460)

#define kStatusBarHeight         20
#define kNavigationBarHeight     44
#define kNavigationheightForIOS7 64
#define kContentHeight           (kApplicationHeight - kNavigationBarHeight)
#define kTabBarHeight            49
#define kSeekTabBarHeight (kIOSVersions>=7.0 ? 0 : 49)

#pragma mark - Font size
/* --------------------------------------------------------------------------------- */
#define kStatementFontSize      [UIFont systemFontOfSize:12]       //Declare font size
#define kNavigationItemFontSize [UIFont systemFontOfSize:15]       //NavigationItem font size
#define kTextFontSize           [UIFont systemFontOfSize:16]       //Text font size
#define kButtonFontSize         [UIFont systemFontOfSize:19]       //Button font size
#define kTitleFontSize          [UIFont systemFontOfSize:20]       //NavigationBar title font


//Screen width
#define WIN_WIDTH  [UIScreen mainScreen].bounds.size.width
//Screen height
#define WIN_HEIGHT [UIScreen mainScreen].bounds.size.height

//Custom NSlog
#ifdef DEBUG
#   define YTLog(XXX) NSLog(@"%@: %@", NSStringFromClass([self class]), XXX)
#else
#   define YTLog()
#endif

#if __LP64__ || (TARGET_OS_EMBEDDED && !TARGET_OS_IPHONE) || TARGET_OS_WIN32 || NS_BUILD_32_LIKE_64
#   define YTIntLog(XXX) NSLog(@"%@: %ld", NSStringFromClass([self class]), XXX)
#else
#   define YTIntLog(XXX) NSLog(@"%@: %d", NSStringFromClass([self class]), XXX)
#endif



//IOS version
#define IOS_SysVersion [[UIDevice currentDevice] systemVersion].floatValue
#define KDocumentFile NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0]

#define NavigationBarHight 64

//---------------------Color macro---------------------------
// RGB color conversion (16, ->10, hex)
#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
// color
#define YT_ColorWithRGB(R, G, B, A) [UIColor colorWithRed:R/255.0f green:G/255.0f blue:B/255.0f alpha:A]

//G－C－D
#define BACK_ACTION(block) dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), block)
#define MAIN_ACTION(block) dispatch_async(dispatch_get_main_queue(),block)

//NSUserDefaults instantiation
#define KUSER_DEFAULT [NSUserDefaults standardUserDefaults]

//block 
typedef void(^VoidBlock)();
typedef BOOL(^BoolBlock)();
typedef int (^IntBlock) ();
typedef id  (^IDBlock)  ();

typedef void(^VoidBlock_int)(NSUInteger);
typedef BOOL(^BoolBlock_int)(int);
typedef int (^IntBlock_int) (int);
typedef id  (^IDBlock_int)  (int);

typedef void(^VoidBlock_string)(NSString*);
typedef BOOL(^BoolBlock_string)(NSString*);
typedef int (^IntBlock_string) (NSString*);
typedef id  (^IDBlock_string)  (NSString*);

typedef void(^VoidBlock_id)(id);
typedef BOOL(^BoolBlock_id)(id);
typedef int (^IntBlock_id) (id);
typedef id  (^IDBlock_id)  (id);

typedef void(^VoidBlock_bool)(BOOL);

#define KSIG            @"megvii_liveness_demo"
#define KAPIKEY         @"api_key"
#define KAPISECRET      @"api_secret"
#define KSERVER         @"server_url"
#define KSHOWIMAGE      @"need_show_images"
#define KDEBUG          @"need_debug"

#define KDEFAULTHOSTAPI     @"http://test.faceid.com"
#define KDEFAULTAPIKEY      @"test"
#define KDEFAULTAPISECRET   @"test"

#endif


#endif /* PAZCLDefineTool_h */
