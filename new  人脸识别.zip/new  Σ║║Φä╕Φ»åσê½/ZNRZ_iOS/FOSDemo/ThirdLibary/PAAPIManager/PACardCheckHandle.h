//
//  PACardCheckHandle.h
//  PACardCheckHandle
//
//  Created by 周宗锂(AI产品应用团队AI工程化开发组) on 2017/9/11.
//  Copyright © 2017年 周宗锂(AI产品应用团队AI工程化开发组). All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

typedef void(^SuccessBlock)(id responseObject);
typedef void(^FailureBlock)(NSError *error);

@interface PACardCheckHandle : NSObject

+ (instancetype)shareInstance;

//人证认别
-(void)faceCheckWithImage:(UIImage *)faceImage name:(NSString *)name cardID:(NSString *)cardID success:(SuccessBlock)success failure:(FailureBlock)failure;

@end
