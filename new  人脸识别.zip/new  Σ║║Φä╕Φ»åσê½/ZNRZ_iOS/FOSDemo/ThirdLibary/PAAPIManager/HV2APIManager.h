//
//  HV2APIManager.h
//  International demo
//
//  Created by 周宗锂 on 2017/7/5.
//  Copyright © 2017年 Will. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

typedef void(^SuccessBlock)(id responseObject);
typedef void(^FailureBlock)(NSError *error);


@interface HV2APIManager : NSObject


+ (instancetype)shareInstance;

+ (NSString *)getImageTokenWithImageData:(NSString *)imageBase64;
//人脸检测
- (void)faceDetectWithImage:(UIImage *)image success:(SuccessBlock)success failure:(FailureBlock)failure;
//活体检测
- (void)biolDetectWithImage:(UIImage *)image success:(SuccessBlock)success failure:(FailureBlock)failure;
//人脸比对
- (void)compareWithImage1:(UIImage *)image1 image2:(UIImage *)image2 success:(SuccessBlock)success failure:(FailureBlock)failure;

@end
