//
//  PAOCRHandle.h
//  PAOCRHandleDemo
//
//  Created by 周宗锂(AI产品应用团队AI工程化开发组) on 2017/8/30.
//  Copyright © 2017年 周宗锂. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

typedef void(^SuccessBlock)(id responseObject);
typedef void(^FailureBlock)(NSError *error);

typedef NS_ENUM(NSInteger, PAOCRCheckCardType) {
    PAOCRCheckCardType_ID_II_Front = 2,
    PAOCRCheckCardType_ID_II_Back = 3,
    PAOCRCheckCardType_ID_Temporary = 4,
    PAOCRCheckCardType_Drivers_icense = 5
};

@interface PAOCRHandle : NSObject
+ (instancetype)shareInstance;

/**
 OCR - 证件识别
 
 @param image 证件照片
 @param checkCardType 证件类型
 @param success 成功回调
 @param failure 失败回调
 */
-(NSURLSessionDataTask *)getInformationWithImage:(UIImage *)image cardType:(PAOCRCheckCardType)checkCardType success:(SuccessBlock)success failure:(FailureBlock)failure;

@end

