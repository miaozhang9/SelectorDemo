//
//  PALivenessDetector.h
//  PALivenessDetector
//
//  Created by 刘沛荣 on 15/11/3.
//  Copyright © 2015年 PA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>


/**
 * 检测过程中的提示
 */
typedef enum EnvironmentalErrorEnum {
    
    ENVIORNMENT_ERROR_TOOCLSE = 0,                      ///<过近<请稍微退后>
    ENVIORNMENT_ERROR_TOOFAR = 1,                       ///<过远<请稍微靠近>
    ENVIORNMENT_ERROR_TOOBRIGHT = 2,                    ///<过于明亮>
    ENVIORNMENT_ERROR_TOODARK = 3,                      ///<过于灰暗>
    ENVIORNMENT_ERROR_TOOPARTIAL = 4,                   ///<过于偏转<请稍微正对摄像头>>
    ENVIORNMENT_ERROR_NOFACE = 5,                       ///<没有人脸<请稍微正对摄像头>>
    ENVIORNMENT_ERROR_FUZZY = 6,                        ///<图片模糊值过高>
    ENVIORNMENT_ERROR_MOVEMENT = 7,                     ///<请保持相对静止>
    ENVIORNMENT_ERROR_MULTIFACE = 8,                    ///<多人存在>
    ENVIORNMENT_ERROR_NORMAL = 9                        ///<正常>
    
} EnvironmentalErrorEnum;


/*!
 * 检测动作类型
 */
typedef enum PALivenessDetectionType {
    
    DETECTION_TYPE_NONE = 0,                            ///<没有动作>
    DETECTION_TYPE_MOUTH = 1,                           ///<张嘴动作>
    DETECTION_TYPE_POS_YAW = 2                          ///<摇头动作>
    
} PALivenessDetectionType;


/*!
 * 检测失败类型
 */
typedef enum PALivenessDetectionFailedType {
    
    DETECTION_FAILED_TYPE_ACTIONBLEND = 0,              ///<动作错误>
    DETECTION_FAILED_TYPE_DiscontinuityAttack = 1,      ///<非连续性攻击>
    DETECTION_FAILED_TYPE_NOTVIDEO = 2,                 ///<不是活体>
    DETECTION_FAILED_TYPE_TIMEOUT = 3,                  ///<超时>
    DETECTION_FAILED_TYPE_Interrupt = 4,                ///<用户操作>
    DETECTION_FAILED_TYPE_License = 5                   ///<摄像头不允许操作>
    
} PALivenessDetectionFailedType;


/*!
 * 检测器配置选项
 */
extern NSString *const PALivenessDetectorStepTimeLimit; //每个检测环节的超时时限
extern NSString *const PALivenessDetectorNumberOfAction;//动作类型活体过程中的动作配置（0：没有动作；1：张嘴动作；2：摇头动作；3：张嘴与摇头随机其一）
extern NSString *const PALivenessDetectorLocation;      //是否输出位置信息（0:否  1:是）


/**
 * 人脸识别信息
 */
struct PAFaceAttr{
    
    bool has_face = false;                              /** 是否包含人脸 */
    float yaw = 0;                                      /** 左右旋转角度 */
    float pitch = 0;                                    /** 上下旋转角度 */
    float blurness_motion = 0;                          /** 运动模糊程度 */
    CGRect face_rect;                                   /** 人脸位置 */
    boolean_t eye_hwratio = 0;                          /** 眼睛睁闭 */
    float brightness = 0;                               /** 亮度 */
    float gaussian = 0;                                 /** 高斯模糊程度 */
    float deflecion_h = 0;                              /** 水平偏角 **/
    float deflecion_v = 0;                              /** 上下偏角 */
    CGPoint eye_left = {0.0,0.0};                       /** 左眼中心坐标 **/
    CGPoint eye_right = {0.0,0.0};                      /** 右眼中心坐标 **/
    float quality = 0;                                  /** 图片质量 **/

};


/*!
 * 单帧检测结果，包含单帧检测出人脸的所有信息，此类无需构造，仅用于回调
 */
@interface PALivenessDetectionFrame : NSObject

@property (readonly) UIImage *image;                    /** 检测帧对应图片 */
@property (readonly) PAFaceAttr attr;                   /** 图片中的人脸属性 */
@property (nonatomic, strong) NSDictionary *locationInfo;        /** 图片位置 */
-(UIImage *)croppedImageOfFace;                         /** 根据人脸位置裁剪仅包含人脸的图片 */
-(PALivenessDetectionFrame *)croppedFrameOfFaceWithMaxImageSize:(int)maxImageSize;

@end


/*!
 *  遵循此协议，在活体检测的过程中触发不同的代理回调方法
 */
@protocol PALivenessProtocolDelegate <NSObject>

@required

/**
 倒计时

 @param currentTime 时间进度
 */
-(void)theCounterDownWithCurrent:(int)currentTime;

/**
 当前活体检测的动作检测失败时，调用此方法。

 @param failedType 动作检测失败的类型
 */
-(void)onDetectionFailed:(PALivenessDetectionFailedType)failedType;

/**
 当前活体检测更换动作时调用

 @param frameType 动作类型
 */
-(void)onDetectionChangeAnimation:(PALivenessDetectionType)frameType;

/**
 检测过程中对于用户行为的建议

 @param testType 检测过程中提示类型
 */
-(void)onFrameDetectedForTheUserBehaviorInTheProcessOfTesting:(EnvironmentalErrorEnum)testType;

/**
 当前活体检测的动作检测成功时，触发此方法

 @param faceInfo 单帧检测结果，包含单帧检测出人脸的所有属性
 */
- (void)onDetectionSuccess:(PALivenessDetectionFrame *)faceInfo;

@optional

/**
 相机权限状态

 @param camerState 相机权限状态
 */
- (void)PAPermissionOfCamer:(AVAuthorizationStatus)camerState;

/**
 Called whenever an AVCaptureVideoDataOutput instance outputs a new video frame.

 @param captureOutput The AVCaptureVideoDataOutput instance that output the frame.
 @param sampleBuffer A CMSampleBuffer object containing the video frame data and additional information about the frame, such as its format and presentation time
 @param connection The AVCaptureConnection from which the video was received.
 */
- (void)PACaptureOutput:(AVCaptureOutput *)captureOutput
  didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer
         fromConnection:(AVCaptureConnection *)connection;

@end


@interface PALivenessDetector : NSObject

/**
 检测器初始化方法

 @param options 检测器配置字典
 @param livenessdelegate 代理
 @return PALivenessDetector
 */
+(PALivenessDetector *)detectorOfOptions:(NSDictionary*)options delegate:(id<PALivenessProtocolDelegate>)livenessdelegate;


/**
 初始化相机方法
 */
-(void)createCamerManager;


/**
 视频流的预览layer 默认全屏大小

 @return 相机预览Layer
 */
-(AVCaptureVideoPreviewLayer *)videoPreview;


/**
 开启视频流
 */
- (void)startRunning;


/**
 关闭视频流
 */
- (void)stopRunning;


/**
 从视频流中获得的原始数据被传递到检测器进行异步实时检测，结果被异步地通知给代理。
 
 @param imgBuffer AVCaptureOutput得到的原始数据流数据
 @param orientation 手机的方向，用来旋转/翻转图像
 UIImageOrientationLeftMirrored:    Home键在下
 UIImageOrientationUpMirrored:      Home键在左
 UIImageOrientationDownMirrored:    Home键在右
 
 @return 成功与否
 */
-(bool)detectWithBuffer:(CMSampleBufferRef)imgBuffer orientation:(UIImageOrientation)orientation;


/**
 获取版本号

 @return 版本号信息
 */
+(NSString *)getVersion;


/**
 重置检测器类的状态，并在用户需要重新启动实时检测过程时调用该函数。
 */
-(void)reset;


@end
