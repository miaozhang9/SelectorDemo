//
//  PAOCRImagePicker.h
//  PAFOS
//
//  Created by 周宗锂(AI产品应用团队AI工程化开发组) on 2017/9/12.
//  Copyright © 2017年 周宗锂. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

/*!
 *  遵循此协议，在活体检测的过程中触发不同的代理回调方法
 */
@protocol PAOCRHandleViewControllerProtocol <NSObject>

@optional

/**
 相机权限状态
 
 @param camerState 相机权限状态
 */
- (void)PAOCRPermissionOfCamer:(AVAuthorizationStatus)camerState;

/**
 Called whenever an AVCaptureVideoDataOutput instance outputs a new video frame.
 
 @param captureOutput The AVCaptureVideoDataOutput instance that output the frame.
 @param image A image object containing the video frame data and additional information about the frame.
 @param connection The AVCaptureConnection from which the video was received.
 */
- (void)PAOCRCaptureOutput:(AVCaptureOutput *)captureOutput
            didOutputImage:(UIImage *)image
            fromConnection:(AVCaptureConnection *)connection;

@end

@interface PAOCRImagePicker : NSObject

/** Callback **/
@property(nonatomic,weak)id<PAOCRHandleViewControllerProtocol>delegate;

/**
 视频流的预览layer 默认全屏大小
 
 @return 相机预览Layer
 */
-(AVCaptureVideoPreviewLayer *)videoPreview;

//开启摄像头
- (void)startRunning;

//关闭摄像头
- (void)stopRunning;



@end




