//
//  FaceDectorViewController.m
//  FOSDemo
//
//  Created by 周宗锂(AI产品应用团队AI工程化开发组) on 2017/9/12.
//  Copyright © 2017年 周宗锂(AI产品应用团队AI工程化开发组). All rights reserved.
//

#import "FaceDectorViewController.h"
#import <OCFTFaceDetect/PATimer.h>
#import <OCFTFaceDetect/OCFTFaceDetector.h>

#define MAIN_ACTION(block) dispatch_async(dispatch_get_main_queue(),block)

@interface FaceDectorViewController ()<OCFTFaceDetectProtocol,PATimerDelegate>

@property (nonatomic, strong) OCFTFaceDetector *livenessDetector;
@property (nonatomic, assign) BOOL starLiveness;
@property (nonatomic, strong) UILabel *tipLable;
@property (nonatomic, strong) UILabel *timeLable;
@property (nonatomic, strong) PATimer *timer;
@end

@implementation FaceDectorViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    [self createFacecheck];     //FaceCheck初始化
    [self setUpCameraLayer];    //加载图层预览
//    [self createTimer];
    [self.view addSubview:self.tipLable];
    [self.view addSubview:self.timeLable];
    
    
}

#pragma mark - Setting/Getting


-(UILabel *)tipLable {
    if (_tipLable == nil) {
        _tipLable = [[UILabel alloc] initWithFrame:CGRectMake(0, 100, [UIScreen mainScreen].bounds.size.width, 50)];
        _tipLable.backgroundColor = [UIColor lightGrayColor];
        _tipLable.textColor = [UIColor whiteColor];
        _tipLable.text = @"初始文字";
        _tipLable.textAlignment = NSTextAlignmentCenter;
    }
    return _tipLable;
}

-(UILabel *)timeLable {
    if (_timeLable == nil) {
        _timeLable = [[UILabel alloc] initWithFrame:CGRectMake(0, 50, [UIScreen mainScreen].bounds.size.width, 50)];
        _timeLable.backgroundColor = [UIColor clearColor];
        _timeLable.textColor = [UIColor whiteColor];
        _timeLable.text = @"time";
        _timeLable.textAlignment = NSTextAlignmentCenter;
        
    }
    return _timeLable;
}


#pragma mark ---- FaceCheck初始化

- (void)createFacecheck{

    NSDictionary *options = @{
                              OCFTFaceDetectorActionTypes:self.actionType,
                              OCFTFaceDetectorOuputLocation:@true
                              };
    self.livenessDetector = [OCFTFaceDetector getDetectorWithOptions:options delegate:self];
    NSString *version = [[OCFTFaceDetector getSDKInfo] version];
    NSLog(@"%------@", version);
}

- (void)starLivenessWithBuff{
    
    [self.timer startTimer];
    self.starLiveness = YES;
}

#pragma mark --- 计时器管理
-(void)createTimer{
    
    self.timer = [[PATimer alloc]init];
    self.timer.timerDelegate = self;
    [self.timer setMaxTime:15];
    
}

#pragma mark --- 相机相关监控

- (void)PermissionOfCamer:(AVAuthorizationStatus)camerState{
    
    if (camerState == AVAuthorizationStatusAuthorized) {
        
        //开启活体检测
        [self starLivenessWithBuff];
    }
    
}

- (void)setUpCameraLayer {
    CALayer * viewLayer = [self.view layer];
    [viewLayer insertSublayer:[self.livenessDetector videoPreview] below:[[viewLayer sublayers] objectAtIndex:0]];
    
}

-(void)onDetectionFailed:(OCFTFaceDetectFailedType)failedType {
    MAIN_ACTION(^{
        NSString *title;
        switch (failedType) {
            case 300:
                title = @"camera auth fail";
                break;
            case 301:
                title =@"Artificial  interrupt";
                break;
            default:
                break;
        }
        NSLog(@"Detection Failed:%@",title);
        [self dismissViewControllerAnimated:YES completion:nil];
    });
}

-(void)onDetectionSuccess:(OCFTFaceDetectionFrame *)faceInfo {
    
    MAIN_ACTION(^{
        if (self.delegate && [self.delegate respondsToSelector:@selector(didCheckFace:)]) {
            [self.timer stopTimer];
            [self.delegate didCheckFace:faceInfo];
        }
        
        [self.navigationController popViewControllerAnimated:YES];
    });
}

-(void)onSuggestingOptimization:(OCFTFaceDetectOptimizationType)type{
    MAIN_ACTION(^{
        NSString *tittleLable;
        switch (type) {
            case 104:
                tittleLable = @"A little farther away,please";
                break;
            case 105:
                tittleLable = @"Just a little closer, please";
                break;
            case 103:
                tittleLable = @"Too bright";
                break;
            case 102:
                tittleLable = @"Too dark";
                break;
            case 110:
                tittleLable = @"Please be facing the camera";
                break;
            case 111:
                tittleLable = @"Please be facing the camera";
                break;
            case 112:
                tittleLable = @"Please be facing the camera";
                break;
            case 113:
                tittleLable = @"Please be facing the camera";
                break;
            case 106:
                tittleLable = @"The picture is too blurry";
                break;
            case 101:
                tittleLable = @"detecting";
                break;
            default:
                break;
        }
        self.tipLable.text = tittleLable;
    });
}

-(void)onDetectionChangeAnimation:(OCFTFaceDetectActionType)type options:(NSDictionary *)options{
    MAIN_ACTION(^{
        NSString *tittleLable;
        switch (type) {
            case 200:
                NSLog(@"Animation None");
                tittleLable = @"";
                self.tipLable.text = tittleLable;
                
                break;
            case 201:
                NSLog(@"Animation Open Mouth");
                tittleLable = @"缓慢张嘴";
                self.tipLable.text = tittleLable;
                
                break;
            case 202:
                NSLog(@"Animation Shake Head");
                tittleLable = @"缓慢摇头";
                self.tipLable.text = tittleLable;
                
                break;
                
            default:
                break;
        }
    });
}

-(void)countdown:(int)timer {
    MAIN_ACTION((^{
        self.timeLable.text = [NSString stringWithFormat:@"%d",timer];
    }));
}

-(void)timerOut{
    
    self.starLiveness = NO;
    [self.timer stopTimer];
    MAIN_ACTION(^{
        [self dismissViewControllerAnimated:YES completion:nil];
    });
    
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    UIViewController *destination = segue.destinationViewController;
    if ([destination respondsToSelector:@selector(setDelegate:)]) {
        [destination setValue:self forKey:@"delegate"];

    }
    
}

-(void)dealloc {
    NSLog(@"FaceDectorViewController dealloc");
}

@end
