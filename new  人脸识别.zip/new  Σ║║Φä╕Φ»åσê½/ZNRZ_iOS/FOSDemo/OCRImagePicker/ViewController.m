//
//  ViewController.m
//  FOSDemo
//
//  Created by 周宗锂(AI产品应用团队AI工程化开发组) on 2017/9/12.
//  Copyright © 2017年 周宗锂(AI产品应用团队AI工程化开发组). All rights reserved.
//

#import "ViewController.h"
//#import "PAOCRImagePicker.h"
#import <OCFTFaceDetect/PAOCRImagePicker.h>
#import "PAOCRHandle.h"

@interface ViewController ()<PAOCRHandleViewControllerProtocol>
{
    int count;
}

@property (nonatomic, strong) PAOCRImagePicker *imagePicker;

@property (nonatomic, strong) dispatch_source_t timer;

@property (nonatomic, assign) BOOL star;

@property (nonatomic, strong) NSMutableArray *taskArray;

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *number;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self setUpCameraLayer];
    
    [self.imagePicker startRunning];
    
    self.star = YES;
    
    self.number = @"";
}

-(PAOCRImagePicker *)imagePicker {
    if (!_imagePicker) {
        _imagePicker = [[PAOCRImagePicker alloc] init];
        _imagePicker.delegate = self;
    }
    return _imagePicker;
}


- (void)setUpCameraLayer {
    CALayer * viewLayer = [self.view layer];
    [viewLayer insertSublayer:[self.imagePicker videoPreview] below:[[viewLayer sublayers] objectAtIndex:0]];
}
#pragma mark - Getting/Setting
-(NSMutableArray *)taskArray {
    if (!_taskArray) {
        _taskArray = [[NSMutableArray alloc] init];
    }
    return _taskArray;
}

#pragma mark - PAOCRHandleViewControllerProtocol

- (void)PAOCRPermissionOfCamer:(AVAuthorizationStatus)camerState{
    
}

- (void)PAOCRCaptureOutput:(AVCaptureOutput *)captureOutput
            didOutputImage:(UIImage *)image
            fromConnection:(AVCaptureConnection *)connection {
    count ++;
    
    if (!self.star) {
        [self.imagePicker stopRunning];
        return;
    }
    
    if (count % 40 == 0) {
        NSData *imgData = UIImageJPEGRepresentation(image,0.5);
        UIImage *img = [UIImage imageWithData:imgData];
        NSURLSessionDataTask *task = [[PAOCRHandle shareInstance] getInformationWithImage:img cardType:PAOCRCheckCardType_ID_II_Front success:^(id responseObject) {
            
            NSLog(@"responseObject :%@",responseObject);
            
            
            NSDictionary *dic = responseObject[@"cardsinfo"][@"card"];
            NSArray *DicArr = [NSArray arrayWithArray:dic[@"item"]];
            
            dispatch_sync(dispatch_get_main_queue(), ^{
                
                for (NSDictionary *dic in DicArr) {
                    
                    NSString *str =   dic[@"_desc"];
                    if ([str isEqualToString:@"姓名"] ) {
                        self.name = dic[@"__text"];
                    }
                    
                    if ([str isEqualToString:@"公民身份号码"]){
                        if ([self.number isEqualToString:dic[@"__text"]]) {
                            if (self.delegate && [self.delegate respondsToSelector:@selector(didCheckCard:)]) {
                                [self.delegate didCheckCard:@{@"name":self.name,@"number":self.number}];
                                //            [self.navigationController popViewControllerAnimated:YES];
                            }
                            [self.imagePicker stopRunning];
                            [self.navigationController popViewControllerAnimated:YES];
                        }
                        self.number = dic[@"__text"];
                    }
                }
                
            });
            
            
        } failure:^(NSError *error) {
            
        }];
        [self.taskArray addObject:task];
    }
    
}

-(void)dealloc {
    NSLog(@"OCR ViewController dealloc");
}


@end
