//
//  PALivenessDetector.h
//  PALivenessDetector
//
//  Created by 刘沛荣 on 15/11/3.
//  Copyright © 2015年 PA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>


/**
 * 检测过程中的提示
 */
typedef enum EnvironmentalErrorEnum {
    
    NORMAL = 101,                        //正常
    TOO_DARK = 102,                      //太暗
    TOO_BRIGHT = 103,                    //太亮
    TOO_CLOSE = 104,                     //太近
    TOO_FAR = 105,                       //太远
    TOO_FUZZY = 106,                     //太模糊
    TOO_PARTIAL = 107,                   //偏转角度
    NO_FACE = 108,                       //没人脸
    MULTIPLE_FACE = 109,                 //多人脸
    TOO_LEFT = 110,                      //太左
    TOO_RIGHT = 111,                     //太右
    TOO_UP  = 112,                       //太上
    TOO_DOWN = 113,                      //太下
    EYES_CLOSED                          //眼睛闭合
    
} EnvironmentalErrorEnum;


/*!
 * 检测动作类型
 */
typedef enum PALivenessDetectionType {
    
    COLLECTFACE = 200,                       //采集正脸
    MOUTH = 201,                         //张嘴提示
    HEAD =  202                          //摇头提示
    
} PALivenessDetectionType;


/*!
 * 检测失败类型
 */
typedef enum PALivenessDetectionFailedType {
    
    DISCONTINUIIY_ATTACK = 301,      //非连续性攻击
    
} PALivenessDetectionFailedType;


/*!
 * 检测器配置选项
 */
extern NSString *const PALivenessDetectorNumberOfAction;//活体过程中的动作配置（0：没有动作；1：张嘴动作；2：摇头动作；3：张嘴与摇头随机其一）
extern NSString *const PALivenessDetectorLocation;      //是否输出位置信息（0:否  1:是）


/**
 * 人脸识别信息
 */
struct PAFaceAttr{
    
    CGRect faceRect;                                    //人脸位置
    float yaw = 0;                                      //左右旋转角度
    float pitch = 0;                                    //上下旋转角度
    float roll = 0;                                     //头部倾斜程度
    float motion_blurness;                              //运动模糊
    float eye_hwratio;                                  //眼闭程度
    float brightness = 0;                               //人脸区域亮度
    float mouthMotion;                                  //嘴巴睁闭程度
    float headMotion;                                   //头部摇头程度
    float quality = 0;                                  //图片质量

};


/*!
 * 单帧检测结果，包含单帧检测出人脸的所有信息，此类无需构造，仅用于回调
 */
@interface PAFaceFrame : NSObject

@property (readonly) UIImage *orignalImage;                      /** 检测帧对应图片 */
@property (readonly) UIImage *headImage;                 /** 检测帧对应人脸图片 */
@property (readonly) PAFaceAttr attr;                     /** 图片中的人脸属性 */
@property (nonatomic, strong) NSDictionary *locationInfo; /** 图片位置 */

@end


/*!
 *  遵循此协议，在活体检测的过程中触发不同的代理回调方法
 */
@protocol PALivenessProtocolDelegate <NSObject>

@required


/**
 当前活体检测的动作检测失败时，调用此方法。

 @param failedType 动作检测失败的类型
 */
-(void)onDetectionFailed:(PALivenessDetectionFailedType)failedType;

/**
 当前活体检测更换动作时调用

 @param frameType 动作类型
 */
-(void)onDetectMotionTips:(PALivenessDetectionType)frameType;

/**
 检测过程中对于用户行为的建议

 @param testType 检测过程中提示类型
 */
-(void)onDetectTips:(EnvironmentalErrorEnum)testType;

/**
 当前活体检测的动作检测成功时，触发此方法

 @param faceInfo 单帧检测结果，包含单帧检测出人脸的所有属性
 */
- (void)onDetectionSuccess:(PAFaceFrame *)faceInfo;

@end


@interface PALivenessDetector : NSObject

/**
 检测器初始化方法

 @param options 检测器配置字典
 @param livenessdelegate 代理
 @return PALivenessDetector
 */
+(PALivenessDetector *)detectorOfOptions:(NSDictionary*)options delegate:(id<PALivenessProtocolDelegate>)livenessdelegate;


/**
 从视频流中获得的原始数据被传递到检测器进行异步实时检测，结果被异步地通知给代理。
 
 @param imgBuffer AVCaptureOutput得到的原始数据流数据
 @param orientation 手机的方向，用来旋转/翻转图像
 UIImageOrientationLeftMirrored:    Home键在下
 UIImageOrientationUpMirrored:      Home键在左
 UIImageOrientationDownMirrored:    Home键在右
 
 @return 成功与否
 */
-(bool)detectWithBuffer:(CMSampleBufferRef)imgBuffer orientation:(UIImageOrientation)orientation;


/**
 获取版本号

 @return 版本号信息
 */
+(NSString *)getVersion;


/**
 重置检测器类的状态，并在用户需要重新启动实时检测过程时调用该函数。
 */
-(void)reset;


@end
