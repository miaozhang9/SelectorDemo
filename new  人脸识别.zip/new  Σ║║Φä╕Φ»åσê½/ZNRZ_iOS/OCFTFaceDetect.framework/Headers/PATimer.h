//
//  PATimer.h
//  FOS_SDK
//
//  Created by prliu on 2017/9/26.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol PATimerDelegate <NSObject>

-(void)countdown:(int)timer;
-(void)timerOut;

@end

@interface PATimer : NSObject

@property (nonatomic,strong)id<PATimerDelegate>timerDelegate;

- (void)setMaxTime:(int)time;
- (void)startTimer;
- (void)stopTimer;

@end
